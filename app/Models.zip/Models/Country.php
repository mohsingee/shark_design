<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

//class for getting country
class Country extends Model
{
    protected $fillable=['name','code','phone_code','name_ar'];
}
