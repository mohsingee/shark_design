<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

//class for creating notifications
class Notification extends Model
{
    protected $fillable=['data','type','notifiable','read_at'];
}
