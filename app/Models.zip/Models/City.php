<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

//class for getting city 
class City extends Model
{
    protected $fillable=['name','code','country_id','border','name_ar'];
}
