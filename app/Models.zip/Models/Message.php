<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

//class for craeting messages
class Message extends Model
{
    public $fillable = ['name', 'message', 'email', 'phone', 'read_at', 'photo', 'subject'];
}
