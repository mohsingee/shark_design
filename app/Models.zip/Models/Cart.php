<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

//class for cart in website
class Cart extends Model
{
    protected $fillable=['user_id','product_id','order_id','quantity','amount','price','status','width','length','unit'];

    //function to get product
    public function product()
    {
        return $this->belongsTo(Product::class, 'product_id');
    }

    //function to get order
    public function order(){
        return $this->belongsTo(Order::class,'order_id');
    }
}
